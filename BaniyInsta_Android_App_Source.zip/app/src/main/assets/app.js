const prices={"Profile Review":199,"Content Growth Plan":499,"Reels Ideas Pack":299};
const getOrders=()=>JSON.parse(localStorage.getItem("ib_orders")||"[]");
const saveOrders=(orders)=>localStorage.setItem("ib_orders",JSON.stringify(orders));
const money=n=>"₹"+Number(n).toLocaleString("en-IN");
const form=document.querySelector("#orderForm"), result=document.querySelector("#orderResult");
document.querySelectorAll(".order-btn").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelector("#serviceSelect").value=btn.dataset.service;
 document.querySelector("#orderSection").scrollIntoView({behavior:"smooth"});
}));
form.addEventListener("submit",e=>{
 e.preventDefault();
 const service=document.querySelector("#serviceSelect").value;
 const order={id:"IB-"+Math.floor(100000+Math.random()*900000),name:document.querySelector("#customerName").value.trim(),username:document.querySelector("#igUsername").value.trim(),service,price:prices[service]||0,message:document.querySelector("#message").value.trim(),status:"Received",created:new Date().toLocaleString("en-IN")};
 const orders=getOrders();orders.unshift(order);saveOrders(orders);
 result.classList.remove("hidden");result.innerHTML=`<b>Order submit ho gaya!</b><br>Order ID: <b>${order.id}</b><br>Service: ${order.service} · ${money(order.price)}<br>Is Order ID ko sambhal kar rakhein aur tracking mein enter karein.`;
 form.reset();
});
document.querySelector("#trackForm").addEventListener("submit",e=>{
 e.preventDefault();const id=document.querySelector("#trackId").value.trim().toUpperCase();const order=getOrders().find(o=>o.id===id);const box=document.querySelector("#trackResult");box.classList.remove("hidden");
 box.innerHTML=order?`<b>${order.id}</b><br>Service: ${order.service}<br>Status: <b>${order.status}</b><br>Order date: ${order.created}`:"Is browser mein yeh Order ID nahi mili. Sahi ID check karein; demo orders isi browser mein save hote hain.";
});
const login=document.querySelector("#adminLogin"), area=document.querySelector("#adminArea");
document.querySelector("#adminToggle").addEventListener("click",()=>{login.classList.toggle("hidden");login.scrollIntoView({behavior:"smooth",block:"center"})});
document.querySelector("#loginForm").addEventListener("submit",e=>{e.preventDefault();if(document.querySelector("#adminPassword").value==="admin123"){login.classList.add("hidden");area.classList.remove("hidden");renderOrders()}else alert("Password sahi nahi hai.");});
function renderOrders(){
 const orders=getOrders();document.querySelector("#orderCount").textContent=orders.length+" orders";
 const list=document.querySelector("#ordersList");
 if(!orders.length){list.innerHTML='<div class="form-card">Abhi koi order nahi hai.</div>';return}
 list.innerHTML=orders.map(o=>`<article class="order-row"><div><div class="order-id">${esc(o.id)}</div><p><b>${esc(o.name)}</b> · ${esc(o.username)}</p><p>${esc(o.service)} · ${money(o.price)} · ${esc(o.created)}</p><p>${esc(o.message||"No extra message")}</p></div><div><select aria-label="Update status" data-id="${esc(o.id)}"><option ${o.status==="Received"?"selected":""}>Received</option><option ${o.status==="In Progress"?"selected":""}>In Progress</option><option ${o.status==="Completed"?"selected":""}>Completed</option><option ${o.status==="Cancelled"?"selected":""}>Cancelled</option></select></div></article>`).join("");
 list.querySelectorAll("select").forEach(sel=>sel.addEventListener("change",()=>{const all=getOrders();const item=all.find(o=>o.id===sel.dataset.id);if(item)item.status=sel.value;saveOrders(all);renderOrders()}));
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
document.querySelector("#exportBtn").addEventListener("click",()=>{const orders=getOrders();if(!orders.length){alert("Export karne ke liye orders nahi hain.");return}const cols=["id","name","username","service","price","status","created","message"];const csv=[cols.join(","),...orders.map(o=>cols.map(k=>'"'+String(o[k]??"").replace(/"/g,'""')+'"').join(","))].join("\r\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="insta-booster-orders.csv";a.click();URL.revokeObjectURL(a.href)});
document.querySelector("#clearBtn").addEventListener("click",()=>{if(confirm("Saare demo orders delete karein?")){localStorage.removeItem("ib_orders");renderOrders()}});
const modal=document.querySelector("#profileModal");document.querySelector("#profileBtn").addEventListener("click",()=>modal.classList.remove("hidden"));document.querySelector("#closeProfile").addEventListener("click",()=>modal.classList.add("hidden"));document.querySelector("#profileOrder").addEventListener("click",()=>{modal.classList.add("hidden");document.querySelector("#orderSection").scrollIntoView({behavior:"smooth"})});modal.addEventListener("click",e=>{if(e.target===modal)modal.classList.add("hidden")});
