BaniyInsta Android App - Starter Project

Yeh Android app ka source project hai, APK installer nahi.
Is project ko APK mein build karne ke liye Android SDK/Gradle build environment chahiye (aam taur par Android Studio computer par).

App features:
- BaniyInsta branding and provided profile photo
- Service cards, order form, local order tracking
- Demo Admin panel (demo password: admin123)
- Data is stored locally on that device/browser storage; this is NOT a live multi-customer order server.
- Real payments and real follower delivery are not connected.

Important:
- Live customer orders from multiple phones need a hosted backend/database.
- Do not use fake/bot followers; offer genuine creator-growth services.
